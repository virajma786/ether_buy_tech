App = {
  web3Provider: null,
  contracts: {},

  init: async function () {
    // Load laptops.
    $.getJSON('../laptops.json', function (data) {
      var laptopsRow = $('#laptopsRow');
      var purchaserRow = $('#purchaserRow');
      var laptopTemplate = $('#laptopTemplate');
      var purchaser = $('#purchaserList');

      for (i = 0; i < data.length; i++) {
        laptopTemplate.find('.panel-title').text(data[i].name);
        laptopTemplate.find('img').attr('src', data[i].picture);
        laptopTemplate.find('.laptop-model').text(data[i].model);
        laptopTemplate.find('.laptop-price').text(data[i].price);
        laptopTemplate.find('.laptop-colour').text(data[i].colour);
        laptopTemplate.find('.btn-purchase').attr('data-id', data[i].id);
        purchaser.find('.laptop-id').text(data[i].id);

        laptopsRow.append(laptopTemplate.html());
        purchaserRow.append(purchaser.html());
      }
    });

    return await App.initWeb3();
  },

  initWeb3: async function () {
    // Modern dapp browsers...
    if (window.ethereum) {
      App.web3Provider = window.ethereum;
      try {
        // Request account access
        await window.ethereum.enable();
      } catch (error) {
        // User denied account access...
        console.error("User denied account access")
      }
    }
    // Legacy dapp browsers...
    else if (window.web3) {
      App.web3Provider = window.web3.currentProvider;
    }
    // If no injected web3 instance is detected, fall back to Ganache
    else {
      App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
    }
    web3 = new Web3(App.web3Provider);


    return App.initContract();
  },

  initContract: function () {
    $.getJSON('laptopspurchase.json', function (data) {
      // Get the necessary contract artifact file and instantiate it with truffle-contract
      var laptopspurchaseArtifact = data;
      App.contracts.laptopspurchase = TruffleContract(laptopspurchaseArtifact);

      // Set the provider for our contract
      App.contracts.laptopspurchase.setProvider(App.web3Provider);

      // Use our contract to retrieve and mark the purchased laptops
      return App.markAdopted();
    });
    return App.bindEvents();
  },

  bindEvents: function () {
    $(document).on('click', '.btn-purchase', App.handleAdopt);
  },

  markAdopted: function (purchasers, account) {
    var laptopspurchaseInstance;

    App.contracts.laptopspurchase.deployed().then(function (instance) {
      laptopspurchaseInstance = instance;

      return laptopspurchaseInstance.getPurchasers.call();
    }).then(function (purchasers) {
      for (i = 0; i < purchasers.length; i++) {
        if (purchasers[i] !== '0x0000000000000000000000000000000000000000') {
          $('.panel-laptop').eq(i).find('button').text('Purchased').attr('disabled', true);
          $('.panel-footer').eq(i).find('p').text(purchasers[i]);
          $('.purchasertext').eq(i).find('#laptop-purchaser').text(purchasers[i]);
        }
      }
    }).catch(function (err) {
      console.log(err.message);
    });
  },

  handleAdopt: function (event) {
    event.preventDefault();

    var laptopId = parseInt($(event.target).data('id'));

    var laptopspurchaseInstance;

    web3.eth.getAccounts(function (error, accounts) {
      if (error) {
        console.log(error);
      }

      var account = accounts[0];

      App.contracts.laptopspurchase.deployed().then(function (instance) {
        laptopspurchaseInstance = instance;

        // Execute purchase as a transaction by sending account
        return laptopspurchaseInstance.purchase(laptopId, { from: account });
      }).then(function (result) {
        return App.markAdopted();
      }).catch(function (err) {
        console.log(err.message);
      });
    });
  }

};

$(function () {
  $(window).load(function () {
    App.init();
  });
});
